package com.company.coronavirusReliableInfos_API;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoronavirusReliableInfosApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
